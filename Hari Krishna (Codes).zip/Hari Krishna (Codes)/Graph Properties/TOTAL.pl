system("perl S2G.pl");
system("perl G2P.pl");
system("perl mergeresults.pl");
