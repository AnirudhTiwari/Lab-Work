system("perl S2G.pl");
system("perl G2C.pl");
system("perl Extract.pl");
